<?php
$link = mysqli_connect('localhost', 'root', 'root', 'gallery') or die(mysqli_error($link));
